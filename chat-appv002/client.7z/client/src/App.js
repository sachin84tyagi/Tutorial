import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';
import './App.css'
const socket = io('http://localhost:5000');

function App() {
  const [text, setText] = useState('');
  const [username, setUsername] = useState('');
  const [receiver, setReceiver] = useState('');
  const [message, setMessage] = useState('');
  const [chat, setChat] = useState([]);
  const [userList, setUserList] = useState([]);

  const register = () => {
    console.log(text)
    if (text.trim()) {
      socket.emit('register', text);
    }
  };

  const sendPrivateMessage = () => {
    if (receiver && message.trim()) {
      socket.emit('private_message', {
        sender: username,
        receiver,
        message
      });
      //setChat([...chat, { sender: 'You', message }]);
      setChat(prev => ({
        ...prev,
        [receiver]: [...(prev[receiver] || []), message]
      }));
      setMessage('');
    }
  };
  useEffect(() => {
    socket.on('userList', (users) => {
      console.log('useEffect users :: ', users)
      setUserList(users);
    });
    return () => {
      //socket.disconnect();
    };
  }, [])

  useEffect(() => {
    socket.on('private_message', ({ sender, to,  message }) => {
      //setChat((prev) => [...prev, { sender, message }]);
      setChat(prev => ({
        ...prev,
        [sender]: [...(prev[sender] || []), message]
      }));
    });

    return () => {
      socket.off('private_message');
    };
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    setUsername(text)
    register()
    setText("")
  }

  return (
    <div className="container" style={{ padding: '20px' }}>
      <aside className="sidebar">
      
      <ul className="nav-links">
        {userList && userList.map((v,k) => (
          <li key={k} className={receiver === v.username ? 'active' : ''} onClick={() => setReceiver(v.username)} style={{cursor: "pointer"}}>{v.username}</li>
        ))}
        
      </ul>
    </aside>
    <main className="main-content">
      <h2>Private Chat App </h2>
      {username ? (<p>You are logged in with name: <strong>{username}</strong></p>) : ""}
      {!username ? (<div>
        <form onSubmit={handleSubmit}>
            <input
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Enter name"
            />
            <button type="submit">Submit</button>
          </form>
      {/* <form>
        <input
          placeholder="Your username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <button onClick={register}>Register</button>
      </form> */}
        
      </div>) : (<div>
      <div style={{ marginTop: '10px' }}>
        <input
          placeholder="Your message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <button onClick={sendPrivateMessage}>Send</button>
      </div>
      <div className="chat-window">
        {receiver ? (
          <>
            <h3>Chat with {receiver}</h3>
            <div className="messages">
              {(chat[receiver] || []).map((msg, index) => (
                <div key={index} className="message">{msg}</div>
              ))}
            </div>
          </>
        ) : (
          <p>Select a user to start chatting</p>
        )}
      </div>
      {/* <ul>
        {chat.map((c, i) => (
          <li key={i}>
            <strong>{c.sender}:</strong> {c.message}
          </li>
        ))}
      </ul> */}
      </div>)}
    </main>
    </div>
  );
}

export default App;
